export class MonthlyMotel {}

